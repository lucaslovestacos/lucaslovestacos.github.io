{
	"format_version": "1.21.6",
	"credit": "Made with Blockbench",
	"parent": "block/block",
	"textures": {
		"4": "Downloads/pixil-frame-0 (11)",
		"6": "block/honey_block_bottom",
		"7": "block/honey_block_side",
		"8": "block/honey_block_top",
		"22": "block/cactus_side",
		"29": "item/sugar",
		"33": "block/nether_wart_block",
		"34": "item/glass_bottle",
		"35": "Downloads/pixil-frame-0 (7)",
		"top": "block/composter_top",
		"bottom": "block/mud_bricks",
		"side": "block/composter_side",
		"particle": "block/composter_bottom"
	},
	"elements": [
		{
			"from": [0, 0, 0],
			"to": [16, 2, 16],
			"faces": {
				"up": {"uv": [0, 0, 16, 16], "texture": "#bottom"},
				"down": {"uv": [0, 0, 16, 16], "texture": "#bottom", "cullface": "down"}
			}
		},
		{
			"from": [0, 0, 0],
			"to": [2, 16, 16],
			"faces": {
				"north": {"uv": [14, 0, 16, 16], "texture": "#side", "cullface": "north"},
				"east": {"uv": [0, 0, 16, 16], "texture": "#side"},
				"south": {"uv": [0, 0, 2, 16], "texture": "#side", "cullface": "south"},
				"west": {"uv": [0, 0, 16, 16], "texture": "#side", "cullface": "west"},
				"up": {"uv": [0, 0, 2, 16], "texture": "#top", "cullface": "up"}
			}
		},
		{
			"from": [14, 0, 0],
			"to": [16, 16, 16],
			"faces": {
				"north": {"uv": [0, 0, 2, 16], "texture": "#side", "cullface": "north"},
				"east": {"uv": [0, 0, 16, 16], "texture": "#side", "cullface": "east"},
				"south": {"uv": [14, 0, 16, 16], "texture": "#side", "cullface": "south"},
				"west": {"uv": [0, 0, 16, 16], "texture": "#side"},
				"up": {"uv": [14, 0, 16, 16], "texture": "#top", "cullface": "up"}
			}
		},
		{
			"from": [2, 0, 0],
			"to": [14, 16, 2],
			"faces": {
				"north": {"uv": [2, 0, 14, 16], "texture": "#side", "cullface": "north"},
				"south": {"uv": [2, 0, 14, 16], "texture": "#side"},
				"up": {"uv": [2, 0, 14, 2], "texture": "#top", "cullface": "up"}
			}
		},
		{
			"from": [2, 0, 14],
			"to": [14, 16, 16],
			"faces": {
				"north": {"uv": [2, 0, 14, 16], "texture": "#side"},
				"south": {"uv": [2, 0, 14, 16], "texture": "#side", "cullface": "south"},
				"up": {"uv": [2, 14, 14, 16], "texture": "#top", "cullface": "up"}
			}
		},
		{
			"from": [-0.05, -0.2, -0.05],
			"to": [16.06, 7.95, 16.06],
			"faces": {
				"north": {"uv": [0, 8, 16, 16], "texture": "#bottom", "cullface": "north"},
				"east": {"uv": [0, 8, 16, 16], "texture": "#bottom", "cullface": "east"},
				"south": {"uv": [0, 8, 16, 16], "texture": "#bottom", "cullface": "south"},
				"west": {"uv": [0, 8, 16, 16], "texture": "#bottom", "cullface": "west"},
				"up": {"uv": [0, 0, 16, 16], "texture": "#bottom"},
				"down": {"uv": [0, 0, 16, 16], "texture": "#bottom", "cullface": "down"}
			}
		},
		{
			"name": "water",
			"from": [1.8, 12, 2],
			"to": [15.8, 12, 15],
			"rotation": {"angle": 0, "axis": "y", "origin": [1.8, 12, 2]},
			"faces": {
				"north": {"uv": [0, 0, 14, 0], "texture": "#missing"},
				"east": {"uv": [0, 0, 13, 0], "texture": "#missing"},
				"south": {"uv": [0, 0, 14, 0], "texture": "#missing"},
				"west": {"uv": [0, 0, 13, 0], "texture": "#missing"},
				"up": {"uv": [0, 0, 16, 16], "texture": "#4"}
			}
		},
		{
			"name": "ingredient",
			"from": [10, 12.3, 2],
			"to": [14, 12.3, 6],
			"rotation": {"angle": 0, "axis": "y", "origin": [12, 12.3, 4]},
			"faces": {
				"north": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"east": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"south": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"west": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#29"}
			}
		},
		{
			"name": "ingredient",
			"from": [10, 12.3, 6],
			"to": [14, 12.3, 10],
			"rotation": {"angle": 0, "axis": "y", "origin": [12, 12.3, 8]},
			"faces": {
				"north": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"east": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"south": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"west": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#29"}
			}
		},
		{
			"name": "ingredient",
			"from": [10, 12.3, 10],
			"to": [14, 12.3, 14],
			"rotation": {"angle": 0, "axis": "y", "origin": [12, 12.3, 12]},
			"faces": {
				"north": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"east": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"south": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"west": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#29"}
			}
		},
		{
			"name": "ingredient",
			"from": [6, 12.3, 10],
			"to": [10, 12.3, 14],
			"rotation": {"angle": 0, "axis": "y", "origin": [8, 12.3, 12]},
			"faces": {
				"north": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"east": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"south": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"west": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#29"}
			}
		},
		{
			"name": "ingredient",
			"from": [6, 12.3, 6],
			"to": [10, 12.3, 10],
			"rotation": {"angle": 0, "axis": "y", "origin": [8, 12.3, 8]},
			"faces": {
				"north": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"east": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"south": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"west": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#29"}
			}
		},
		{
			"name": "ingredient",
			"from": [6, 12.3, 2],
			"to": [10, 12.3, 6],
			"rotation": {"angle": 0, "axis": "y", "origin": [8, 12.3, 4]},
			"faces": {
				"north": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"east": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"south": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"west": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#29"}
			}
		},
		{
			"name": "ingredient",
			"from": [2, 12.3, 10],
			"to": [6, 12.3, 14],
			"rotation": {"angle": 0, "axis": "y", "origin": [4, 12.3, 12]},
			"faces": {
				"north": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"east": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"south": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"west": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#29"}
			}
		},
		{
			"name": "ingredient",
			"from": [2, 12.3, 6],
			"to": [6, 12.3, 10],
			"rotation": {"angle": 0, "axis": "y", "origin": [4, 12.3, 8]},
			"faces": {
				"north": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"east": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"south": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"west": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#29"}
			}
		},
		{
			"from": [2, 10.4, 6],
			"to": [6, 14.4, 10],
			"rotation": {"angle": 0, "axis": "y", "origin": [4, 10.4, 8]},
			"faces": {
				"north": {"uv": [1, 0, 15, 16], "rotation": 90, "texture": "#22"},
				"east": {"uv": [0, 0, 14, 0], "texture": "#missing"},
				"south": {"uv": [0, 0, 13, 0], "texture": "#missing"},
				"west": {"uv": [0, 0, 14, 0], "texture": "#missing"},
				"up": {"uv": [1, 0, 15, 16], "rotation": 90, "texture": "#22"}
			}
		},
		{
			"name": "ingredient",
			"from": [2, 12.3, 2],
			"to": [6, 12.3, 6],
			"rotation": {"angle": 0, "axis": "y", "origin": [4, 12.3, 4]},
			"faces": {
				"north": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"east": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"south": {"uv": [0, 0, 13, 0], "texture": "#29"},
				"west": {"uv": [0, 0, 14, 0], "texture": "#29"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#29"}
			}
		},
		{
			"from": [2, 17.3, 17.4],
			"to": [10, 25.3, 17.4],
			"rotation": {"angle": 20, "axis": "y", "origin": [8, 19.3, 17.4]},
			"faces": {
				"north": {"uv": [0, 0, 16, 16], "texture": "#34"},
				"east": {"uv": [0, 0, 13, 0], "rotation": 90, "texture": "#34"},
				"west": {"uv": [0, 0, 13, 0], "rotation": 270, "texture": "#34"},
				"up": {"uv": [0, 0, 14, 0], "texture": "#34"},
				"down": {"uv": [0, 0, 14, 0], "rotation": 180, "texture": "#34"}
			}
		},
		{
			"from": [8.1, 16.6, 9.5],
			"to": [8.1, 24.6, 17.5],
			"rotation": {"angle": -37.5, "axis": "y", "origin": [8.1, 18.6, 11.5]},
			"faces": {
				"north": {"uv": [0, 0, 13, 0], "rotation": 90, "texture": "#34"},
				"south": {"uv": [0, 0, 13, 0], "rotation": 270, "texture": "#34"},
				"west": {"uv": [0, 0, 16, 16], "texture": "#35"},
				"up": {"uv": [0, 0, 14, 0], "rotation": 270, "texture": "#34"},
				"down": {"uv": [0, 0, 14, 0], "rotation": 270, "texture": "#34"}
			}
		},
		{
			"name": "cube_under",
			"from": [2, -0.5, 2],
			"to": [14, 11.5, 14],
			"rotation": {"angle": 0, "axis": "y", "origin": [2, -0.5, 2]},
			"faces": {
				"north": {"uv": [0, 0, 16, 16], "texture": "#33"},
				"east": {"uv": [0, 0, 16, 16], "texture": "#33"},
				"south": {"uv": [0, 0, 16, 16], "texture": "#33"},
				"west": {"uv": [0, 0, 16, 16], "texture": "#33"},
				"up": {"uv": [0, 0, 16, 16], "texture": "#33"},
				"down": {"uv": [0, 0, 12, 12], "texture": "#33"}
			}
		},
		{
			"name": "honey_1",
			"from": [2, -0.6, 2],
			"to": [14, 11.4, 14],
			"rotation": {"angle": 0, "axis": "y", "origin": [2, -0.6, 2]},
			"faces": {
				"north": {"uv": [0, 0, 16, 16], "texture": "#6"},
				"east": {"uv": [0, 0, 16, 16], "texture": "#6"},
				"south": {"uv": [0, 0, 16, 16], "texture": "#6"},
				"west": {"uv": [0, 0, 16, 16], "texture": "#6"},
				"up": {"uv": [0, 0, 16, 16], "texture": "#6"},
				"down": {"uv": [0, 0, 12, 12], "texture": "#missing"}
			}
		},
		{
			"name": "honey_2",
			"from": [3.1, -0.6, 3],
			"to": [13.1, 10.4, 13],
			"rotation": {"angle": 0, "axis": "y", "origin": [2.1, -0.6, 2]},
			"faces": {
				"north": {"uv": [0, 0, 16, 16], "texture": "#7"},
				"east": {"uv": [0, 0, 16, 16], "texture": "#7"},
				"south": {"uv": [0, 0, 16, 16], "texture": "#7"},
				"west": {"uv": [0, 0, 16, 16], "texture": "#7"},
				"up": {"uv": [0, 0, 16, 16], "texture": "#8"},
				"down": {"uv": [0, 0, 12, 12], "texture": "#missing"}
			}
		}
	],
	"display": {
		"thirdperson_righthand": {
			"rotation": [75, 45, 0],
			"translation": [0, 2.5, 0],
			"scale": [0.375, 0.375, 0.375]
		},
		"firstperson_righthand": {
			"rotation": [0, 45, 0],
			"scale": [0.4, 0.4, 0.4]
		},
		"firstperson_lefthand": {
			"rotation": [0, -135, 0],
			"scale": [0.4, 0.4, 0.4]
		},
		"ground": {
			"translation": [0, 3, 0],
			"scale": [0.25, 0.25, 0.25]
		},
		"gui": {
			"rotation": [30, -135, 0],
			"scale": [0.625, 0.625, 0.625]
		},
		"fixed": {
			"scale": [0.5, 0.5, 0.5]
		}
	},
	"groups": [
		{
			"name": "composter",
			"origin": [8, 8, 8],
			"color": 0,
			"children": [0, 1, 2, 3, 4]
		},
		{
			"name": "slab",
			"origin": [8, 8, 8],
			"color": 0,
			"children": [5]
		},
		6,
		7,
		8,
		9,
		10,
		11,
		12,
		13,
		14,
		15,
		16,
		17,
		18,
		19,
		20,
		21
	]
}