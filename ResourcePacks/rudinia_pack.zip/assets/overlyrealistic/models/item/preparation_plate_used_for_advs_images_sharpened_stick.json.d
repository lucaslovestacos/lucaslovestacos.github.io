{
	"format_version": "1.21.6",
	"credit": "Made with Blockbench",
	"parent": "minecraft:block/template_leaf_litter_4",
	"ambientocclusion": false,
	"textures": {
		"0": "block/stone",
		"1": "Downloads/pixil-frame-0 (6)",
		"2": "Downloads/pixil-frame-0 (4)",
		"8": "overlyrealistic:item/sharpened_stick",
		"9": "Downloads/pixil-frame-0 (7)",
		"particle": "Downloads/pixil-frame-0 (4)"
	},
	"elements": [
		{
			"from": [1, 0, 1],
			"to": [15, 1, 15],
			"faces": {
				"north": {"uv": [1, 15, 15, 16], "texture": "#0"},
				"east": {"uv": [1, 15, 15, 16], "texture": "#0"},
				"south": {"uv": [1, 15, 15, 16], "texture": "#0"},
				"west": {"uv": [1, 15, 15, 16], "texture": "#0"},
				"up": {"uv": [1, 1, 15, 15], "texture": "#0"},
				"down": {"uv": [1, 1, 15, 15], "texture": "#0", "cullface": "down"}
			}
		},
		{
			"from": [0, 1.25, 0],
			"to": [16, 1.25, 16],
			"rotation": {"angle": -10, "axis": "x", "origin": [8, 1.25, 8]},
			"faces": {
				"up": {"uv": [0, 0, 16, 16], "texture": "#1", "tintindex": 0},
				"down": {"uv": [0, 16, 16, 0], "texture": "#1", "tintindex": 0}
			}
		},
		{
			"from": [0, 1.25, 0],
			"to": [16, 1.25, 16],
			"rotation": {"angle": 10, "axis": "z", "origin": [8, 1.25, 8]},
			"faces": {
				"up": {"uv": [0, 0, 16, 16], "rotation": 270, "texture": "#1", "tintindex": 0},
				"down": {"uv": [0, 16, 16, 0], "rotation": 90, "texture": "#1", "tintindex": 0}
			}
		},
		{
			"from": [0, 1.25, 0],
			"to": [16, 1.25, 16],
			"rotation": {"angle": 10, "axis": "x", "origin": [8, 1.25, 8]},
			"faces": {
				"up": {"uv": [0, 0, 16, 16], "texture": "#1", "tintindex": 0},
				"down": {"uv": [0, 16, 16, 0], "texture": "#1", "tintindex": 0}
			}
		},
		{
			"from": [0, 1.25, 0],
			"to": [16, 1.25, 16],
			"rotation": {"angle": -10, "axis": "z", "origin": [8, 1.25, 8]},
			"faces": {
				"up": {"uv": [0, 0, 16, 16], "rotation": 270, "texture": "#1", "tintindex": 0},
				"down": {"uv": [0, 16, 16, 0], "rotation": 90, "texture": "#1", "tintindex": 0}
			}
		},
		{
			"from": [0, 1.3, -0.3],
			"to": [16, 1.3, 15.7],
			"shade": false,
			"rotation": {"angle": 0, "axis": "x", "origin": [8, 1.3, 7.7]},
			"faces": {
				"up": {"uv": [16, 0, 0, 16], "rotation": 180, "texture": "#2", "tintindex": 1},
				"down": {"uv": [0, 0, 16, 16], "texture": "#2", "tintindex": 1}
			}
		},
		{
			"from": [-0.5, 2.9, -2.4],
			"to": [17.5, 2.9, 15.6],
			"rotation": {"angle": -41, "axis": "y", "origin": [8.5, 2.9, 6.6]},
			"faces": {
				"up": {"uv": [0, 0, 16, 16], "texture": "#8"}
			}
		},
		{
			"from": [-2.8, 5.7, 18.1],
			"to": [7.2, 15.7, 18.1],
			"rotation": {"angle": 24, "axis": "y", "origin": [-1.5, 14.7, 18.1]},
			"faces": {
				"north": {"uv": [0, 0, 16, 16], "texture": "#2"}
			}
		},
		{
			"from": [1.51564, 12.6, 6.32205],
			"to": [7.51564, 12.6, 12.32205],
			"rotation": {"angle": -42, "axis": "x", "origin": [2.51564, 12.6, 11.32205]},
			"faces": {
				"up": {"uv": [0, 0, 16, 16], "rotation": 180, "texture": "#9"}
			}
		}
	],
	"display": {
		"thirdperson_righthand": {
			"translation": [0, 3.75, 0],
			"scale": [0.5, 0.5, 0.5]
		},
		"thirdperson_lefthand": {
			"translation": [0, 3.75, 0],
			"scale": [0.5, 0.5, 0.5]
		},
		"firstperson_righthand": {
			"translation": [-1.25, 7.25, 0.75],
			"scale": [0.6, 0.6, 0.6]
		},
		"firstperson_lefthand": {
			"translation": [-1.75, 7.25, 0.75],
			"scale": [0.6, 0.6, 0.6]
		},
		"ground": {
			"translation": [0, 2.75, 0],
			"scale": [0.4, 0.4, 0.4]
		},
		"gui": {
			"rotation": [31.97, -14.29, -3],
			"translation": [0.5, 1.75, 0],
			"scale": [0.8, 0.8, 0.8]
		},
		"head": {
			"translation": [0, 14.25, 0]
		},
		"fixed": {
			"rotation": [-90.5, 0, 0],
			"translation": [0, 0, -7.5]
		}
	},
	"groups": [
		{
			"name": "pressure_plate_up",
			"origin": [8, 8, 8],
			"color": 0,
			"children": [0]
		},
		{
			"name": "leaf_litter_4",
			"origin": [8, 8, 8],
			"color": 0,
			"children": []
		},
		{
			"name": "template_leaf_litter_4",
			"origin": [8, 8, 8],
			"color": 0,
			"children": [1, 2]
		},
		{
			"name": "template_leaf_litter_4",
			"origin": [8, 8, 8],
			"color": 0,
			"children": [3, 4]
		},
		{
			"name": "vine",
			"origin": [8, 8, 8],
			"color": 1,
			"children": [5]
		},
		6,
		7,
		8
	]
}