{
	"format_version": "1.21.6",
	"credit": "Made with Blockbench",
	"textures": {
		"0": "block/cobblestone",
		"10": "block/gravel",
		"11": "item/sweet_berries",
		"particle": "block/cobblestone"
	},
	"elements": [
		{
			"from": [0, 0, 0],
			"to": [16, 8, 16],
			"rotation": {"angle": 0, "axis": "y", "origin": [8, 5, 8]},
			"faces": {
				"north": {"uv": [0, 0, 16, 8], "texture": "#0"},
				"east": {"uv": [0, 0, 16, 8], "texture": "#0"},
				"south": {"uv": [0, 0, 16, 8], "texture": "#0"},
				"west": {"uv": [0, 0, 16, 8], "texture": "#0"},
				"up": {"uv": [0, 0, 8, 6.75], "texture": "#0"},
				"down": {"uv": [0, 0, 8, 6.75], "texture": "#0"}
			}
		},
		{
			"name": "ingredient",
			"from": [8.1, 8.6, -0.1],
			"to": [16.1, 8.6, 7.9],
			"rotation": {"angle": 0, "axis": "y", "origin": [11.1, 8.6, 4.9]},
			"faces": {
				"north": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"east": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"south": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"west": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#11"}
			}
		},
		{
			"name": "ingredient_cube",
			"from": [8.1, 4.6, -0.1],
			"to": [16.1, 12.6, 7.9],
			"rotation": {"angle": 0, "axis": "y", "origin": [11.1, 4.6, 4.9]},
			"faces": {
				"north": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"east": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"south": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"west": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#10"}
			}
		},
		{
			"name": "ingredient_cube",
			"from": [8.1, 4.6, 8.3],
			"to": [16.1, 12.6, 16.3],
			"rotation": {"angle": 0, "axis": "y", "origin": [11.1, 4.6, 13.3]},
			"faces": {
				"north": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"east": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"south": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"west": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#10"}
			}
		},
		{
			"name": "ingredient_cube",
			"from": [-0.2, 4.6, -0.1],
			"to": [7.8, 12.6, 7.9],
			"rotation": {"angle": 0, "axis": "y", "origin": [2.8, 4.6, 4.9]},
			"faces": {
				"north": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"east": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"south": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"west": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#10"}
			}
		},
		{
			"name": "ingredient_cube",
			"from": [-0.2, 4.6, 8.3],
			"to": [7.8, 12.6, 16.3],
			"rotation": {"angle": 0, "axis": "y", "origin": [2.8, 4.6, 13.3]},
			"faces": {
				"north": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"east": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"south": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"west": {"uv": [0, 0, 16, 8], "texture": "#10"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#10"}
			}
		},
		{
			"name": "ingredient",
			"from": [8.1, 8.6, 8],
			"to": [16.1, 8.6, 16],
			"rotation": {"angle": 0, "axis": "y", "origin": [11.1, 8.6, 13]},
			"faces": {
				"north": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"east": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"south": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"west": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#11"}
			}
		},
		{
			"name": "ingredient",
			"from": [0.1, 8.6, -0.1],
			"to": [8.1, 8.6, 7.9],
			"rotation": {"angle": 0, "axis": "y", "origin": [3.1, 8.6, 4.9]},
			"faces": {
				"north": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"east": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"south": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"west": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#11"}
			}
		},
		{
			"name": "ingredient",
			"from": [0.1, 8.6, 8],
			"to": [8.1, 8.6, 16],
			"rotation": {"angle": 0, "axis": "y", "origin": [3.1, 8.6, 13]},
			"faces": {
				"north": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"east": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"south": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"west": {"uv": [0, 0, 16, 8], "texture": "#11"},
				"up": {"uv": [0, 0, 16, 16], "rotation": 90, "texture": "#11"}
			}
		},
		{
			"from": [2, 0, -2],
			"to": [16, 12, 0],
			"rotation": {"angle": 0, "axis": "y", "origin": [8, 5, 8]},
			"faces": {
				"north": {"uv": [0, 0, 7, 5], "texture": "#0"},
				"south": {"uv": [0, 0, 7, 5], "texture": "#0"},
				"up": {"uv": [0, 0, 1, 7], "rotation": 90, "texture": "#0"},
				"down": {"uv": [1, 0, 2, 7], "rotation": 270, "texture": "#0"}
			}
		},
		{
			"from": [-2, 0, -2],
			"to": [2, 12, 0],
			"rotation": {"angle": 0, "axis": "y", "origin": [8, 5, 8]},
			"faces": {
				"north": {"uv": [0, 0, 2, 7], "texture": "#0"},
				"east": {"uv": [0, 0, 2, 12], "texture": "#0"},
				"south": {"uv": [0, 0, 2, 6], "texture": "#0"},
				"west": {"uv": [14, 3, 15, 9], "texture": "#0"},
				"up": {"uv": [0, 0, 1, 2], "rotation": 90, "texture": "#0"},
				"down": {"uv": [0, 0, 1, 2], "rotation": 270, "texture": "#0"}
			}
		},
		{
			"from": [2, 0, 16],
			"to": [16, 12, 18],
			"rotation": {"angle": 0, "axis": "y", "origin": [8, 5, 26]},
			"faces": {
				"north": {"uv": [0, 0, 7, 5], "texture": "#0"},
				"south": {"uv": [0, 0, 7, 5], "texture": "#0"},
				"up": {"uv": [0, 0, 1, 7], "rotation": 90, "texture": "#0"},
				"down": {"uv": [0, 0, 1, 6], "rotation": 270, "texture": "#0"}
			}
		},
		{
			"from": [-2, 0, 16],
			"to": [2, 12, 18],
			"rotation": {"angle": 0, "axis": "y", "origin": [8, 5, 26]},
			"faces": {
				"north": {"uv": [0, 0, 2, 7], "texture": "#0"},
				"east": {"uv": [0, 0, 2, 12], "texture": "#0"},
				"south": {"uv": [0, 0, 2, 6], "texture": "#0"},
				"west": {"uv": [9, 3, 10, 9], "texture": "#0"},
				"up": {"uv": [0, 0, 1, 2], "rotation": 90, "texture": "#0"},
				"down": {"uv": [0, 0, 1, 2], "rotation": 270, "texture": "#0"}
			}
		},
		{
			"from": [16, 0, 14],
			"to": [18, 12, 18],
			"rotation": {"angle": 0, "axis": "y", "origin": [17, 6, 16]},
			"faces": {
				"north": {"uv": [0, 0, 2, 12], "texture": "#0"},
				"east": {"uv": [0, 0, 2, 6], "texture": "#0"},
				"south": {"uv": [8, 3, 9, 8], "texture": "#0"},
				"west": {"uv": [0, 0, 2, 7], "texture": "#0"},
				"up": {"uv": [0, 0, 1, 2], "texture": "#0"},
				"down": {"uv": [0, 0, 1, 2], "texture": "#0"}
			}
		},
		{
			"from": [16, 0, -2],
			"to": [18, 12, 14],
			"rotation": {"angle": 0, "axis": "y", "origin": [17, 6, 12]},
			"faces": {
				"north": {"uv": [0, 0, 1, 5], "texture": "#0"},
				"east": {"uv": [0, 0, 7, 5], "texture": "#0"},
				"south": {"uv": [8, 3, 10, 10], "texture": "#0"},
				"west": {"uv": [0, 0, 7, 5], "texture": "#0"},
				"up": {"uv": [1, 0, 2, 7], "texture": "#0"},
				"down": {"uv": [0, 0, 1, 7], "texture": "#0"}
			}
		},
		{
			"from": [-2, 0, 0],
			"to": [0, 12, 16],
			"rotation": {"angle": 0, "axis": "y", "origin": [-1, 6, 14]},
			"faces": {
				"north": {"uv": [0, 0, 1, 5], "texture": "#0"},
				"east": {"uv": [0, 0, 7, 5], "texture": "#0"},
				"south": {"uv": [8, 3, 10, 10], "texture": "#0"},
				"west": {"uv": [0, 0, 7, 5], "texture": "#0"},
				"up": {"uv": [0, 0, 1, 2], "texture": "#0"},
				"down": {"uv": [0, 0, 1, 7], "texture": "#0"}
			}
		}
	]
}