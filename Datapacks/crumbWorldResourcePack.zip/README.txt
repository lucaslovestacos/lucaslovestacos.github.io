give @s minecraft:shulker_shell{display:{Name:'{"text":"Common Loot Box Shell","color":"green"}'},CustomModelData:1200001} 1

give @s minecraft:shulker_shell{display:{Name:'{"text":"Uncommon Loot Box Shell","color":"blue"}'},CustomModelData:1200002} 1

give @s minecraft:shulker_shell{display:{Name:'{"text":"Strange Loot Box Shell","color":"yellow"}'},CustomModelData:1200003} 1

give @s minecraft:shulker_shell{display:{Name:'{"text":"Unusual Loot Box Shell","color":"orange"}'},CustomModelData:1200004} 1

give @s minecraft:shulker_shell{display:{Name:'{"text":"Legendary Loot Box Shell","color":"purple"}'},CustomModelData:1200005} 1